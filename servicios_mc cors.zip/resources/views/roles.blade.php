@extends('layouts.dashboard')

@section('content')
<Roles-component></Roles-component>
@endsection