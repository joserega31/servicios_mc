@extends('layouts.dashboard')

@section('content')
<funcionrol-component></funcionrol-component>
@endsection