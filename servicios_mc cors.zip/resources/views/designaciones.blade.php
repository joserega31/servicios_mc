@extends('layouts.dashboard')

@section('content')
<designaciones-component><designaciones-component>
@endsection