@extends('layouts.dashboard')

@section('content')
<ingenios-component><ingenios-component>
@endsection