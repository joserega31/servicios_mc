@extends('layouts.dashboard')

@section('content')

<Servicio-component></Servicio-component>

@endsection