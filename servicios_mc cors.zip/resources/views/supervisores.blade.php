@extends('layouts.dashboard')

@section('content')

<supervisores-component><supervisores-component>

@endsection