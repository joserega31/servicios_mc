@extends('layouts.dashboard')

@section('content')
<home-component></home-component>
@endsection