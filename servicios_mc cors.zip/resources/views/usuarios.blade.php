@extends('layouts.dashboard')

@section('content')
<usuarios-component></usuarios-component>
@endsection