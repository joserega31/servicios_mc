@extends('layouts.dashboard')

@section('content')
<tiposserv-component><tiposserv-component>
@endsection