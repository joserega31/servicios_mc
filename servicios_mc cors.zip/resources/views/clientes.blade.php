@extends('layouts.dashboard')

@section('content')

<Clientes-component></Clientes-component>

@endsection