@extends('layouts.dashboard')

@section('content')

<metpagos-component></metpagos-component>

@endsection