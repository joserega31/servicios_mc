@extends('layouts.dashboard')

@section('content')
<lineasprod-component></lineasprod-component>
@endsection