@extends('layouts.dashboard')

@section('content')
<tarifarios-component><tarifarios-component>
@endsection