@extends('layouts.dashboard')

@section('content')
<estpagos-component><estpagos-component>
@endsection