<?php $__env->startSection('content'); ?>
<Comercio-component></Comercio-component>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Proyectos Programacion\Proyectos laravel\reto\reto_comercio\resources\views/home.blade.php ENDPATH**/ ?>