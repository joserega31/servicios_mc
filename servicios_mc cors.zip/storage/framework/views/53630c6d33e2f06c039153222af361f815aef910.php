

<?php $__env->startSection('content'); ?>

<Servicio-component></Servicio-component>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Proyectos Programacion\servicios_mc\resources\views/servicio.blade.php ENDPATH**/ ?>