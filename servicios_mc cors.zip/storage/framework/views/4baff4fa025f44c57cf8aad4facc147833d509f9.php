

<?php $__env->startSection('content'); ?>
    <configuracion-component :user="<?php echo e(Auth::user()); ?>"><configuracion-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Proyectos Programacion\servicios_mc\resources\views/configuracion.blade.php ENDPATH**/ ?>