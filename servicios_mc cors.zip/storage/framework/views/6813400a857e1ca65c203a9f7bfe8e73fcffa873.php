<?php echo e($slot); ?>

<?php /**PATH C:\Users\user\Documents\Proyectos Programacion\servicios_mc\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>